@extends('main')
@section('name')
    <h3>Edit Nilai {{ $siswa->nama_siswa }}</h3>
@endsection
@section('content')
    @if( session('error'))
    <p class="text-danger">{{ session ('error') }}</p>
    @endif
    @if ($errors->any())
    <ul class="text-danger">
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
    @endif

    <form class="form" action="/nilai-raport/update/{{ $nilai->id }}" method="post">
        @method('put')
        @csrf

        <table>
            <tr class="position">
                <td>
                    <label for="siswa_id">Nama Siswa:</label>
                </td>
                <td>
                    <input value="{{ $siswa->id }}" type="hidden" name="siswa_id" id="siswa_id" step="0.01" required>
                    <input value="{{ $siswa->nama_siswa }}" type="text" step="0.01" readonly>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="matematika">Matematika:</label>
                </td>
                <td>
                    <input value="{{ old('matematika', $nilai->matematika) }}" type="number" name="matematika" id="matematika" min="0" max="100" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="indonesia">Indonesia:</label>
                </td>
                <td>
                    <input value="{{ old('indonesia', $nilai->indonesia) }}" type="number" name="indonesia" id="indonesia" min="0" max="100" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="inggris">Inggris:</label>
                </td>
                <td>
                    <input value="{{ old('inggris', $nilai->inggris) }}" type="number" name="inggris" id="inggris" min="0" max="100" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="kejuruan">Kejuruan:</label>
                </td>
                <td>
                    <input value="{{ old('kejuruan', $nilai->kejuruan) }}" type="number" name="kejuruan" id="kejuruan" min="0" max="100" step="0.01" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="pilihan">Pilihan:</label>
                </td>
                <td>
                    <input value="{{ old('pilihan', $nilai->pilihan) }}" type="number" name="pilihan" id="pilihan" min="0" max="100" step="0.01" required>
                </td>
            </tr>
        </table>
        <button class="button-submit" type="submit">Simpan</button>
    </form>
@endsection