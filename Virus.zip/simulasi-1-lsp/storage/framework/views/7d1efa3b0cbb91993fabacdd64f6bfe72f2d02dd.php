<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <script src="<?php echo e(asset('assets/js/script.js')); ?>" defer></script>
    <title>Form Login</title>
</head>
<body>

    <div class="container">
        <div class="logo">
            <img src="<?php echo e(asset('assets/img/smkn1cibinong.png')); ?>">
        </div>
        <div class="form-container">
            <div class="tab">
                <button class="tablinks active" onclick="opentab(event, 'Student')">Login Siswa</button>
                <button class="tablinks" onclick="opentab(event, 'Teacher')">Login Walas</button>
            </div>

            <div id="Student" class="tabcontent" style="display: block;">
                <h2>Login Siswa</h2>
                <h3><?php echo e(session('error')); ?></h3>
                <form action="/login-siswa" method="POST">
                <?php echo csrf_field(); ?>
                <label>NISN</label>
                <input type="text" name="txt_nis" placeholder="Masukkan NISN Anda" required>

                <label>PASSWORD</label>
                <input type="password" name="txt_pass" placeholder="Masukkan Password Anda" required>

                <button type="submit">Login</button>
            </form>
            </div>

            <div id="Teacher" class="tabcontent" style="display:none;">
                <h2>Login Walas</h2>
                <h3><?php echo e(session('error')); ?></h3>
                <form action="/login-walas" method="POST">
                    <?php echo csrf_field(); ?>
                    <label>NIG</label>
                    <input type="text" name="txt_nig" placeholder="Masukkan NIG Anda" required>

                    <label>PASSWORD</label>
                    <input type="password" name="txt_pass" placeholder="Masukkan Password Anda" required>

                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\RPL\Desktop\LSP 2024\lsp-eraport\resources\views/login.blade.php ENDPATH**/ ?>