<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSP-ERAPORT</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
</head>
<body>
    <div class="header">
        <img class="badge" src="<?php echo e(asset('assets/img/smkn1cibinong.png')); ?>" alt="">
        <img class="banner" src="<?php echo e(asset('assets/img/smkhebat.jpg')); ?>" alt="">
    </div>
    
    <div class="sidebar">
        <?php if(session('role') == 'Walas'): ?>
        <a href="/nilai-raport/create">INPUT NILAI</a>
        <a href="/nilai-raport/index">REKAP NILAI</a>
        <?php else: ?>
        <a href="/nilai-raport/show">REKAP NILAI</a>
        <?php endif; ?>
        <a href="/logout">LOGOUT</a>
    </div>

    <div class="container">
        <?php echo $__env->yieldContent('name'); ?>
        <div class="greet">
            <h3 class="">Halo <?php echo e(session('nama')); ?></h3>
        </div>
    </div>
    <div style="text-align: center;">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\laragon2\www\simulasi-1-lsp\resources\views/main.blade.php ENDPATH**/ ?>