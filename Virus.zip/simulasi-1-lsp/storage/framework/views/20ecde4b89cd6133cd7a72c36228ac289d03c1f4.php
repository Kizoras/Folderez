

<?php $__env->startSection('name'); ?>
    <h3>Tambahkan Nilai</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3>Create Nilai</h3>
    <?php if(session('error')): ?>
    <p class="text-danger"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <form class="form" action="/nilai-raport/store" method="post">
        <?php echo csrf_field(); ?>
        <table>
            <tr class="position">
                <td>
                    <label for="siswa_id">Nama Siswa:</label>
                </td>
                <td>
                    <select name="siswa_id" id="siswa_id" required>
                        <option value="">Pilih Siswa</option>
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($each->id); ?>"><?php echo e($each->nama_siswa); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="matematika">Matematika:</label>
                </td>
                <td>
                    <input type="number" name="matematika" id="matematika" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="indonesia">Indonesia:</label>
                </td>
                <td>
                    <input type="number" name="indonesia" id="indonesia" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="inggris">Inggris:</label>
                </td>
                <td>
                    <input type="number" name="inggris" id="inggris" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="kejuruan">Kejuruan:</label>
                </td>
                <td>
                    <input type="number" name="kejuruan" id="kejuruan" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="pilihan">Pilihan:</label>
                </td>
                <td>
                    <input type="number" name="pilihan" id="pilihan" step="0.01" required>
                </td>
            </tr>
        </table>
        <button class="button-submit" type="submit">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\www\simulasi-1-lsp\resources\views/nilai/create.blade.php ENDPATH**/ ?>