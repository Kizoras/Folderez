
<?php $__env->startSection('name'); ?>
    <h3>Rekap Nilai</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<center>

    <h1>REKAP NILAI RAPORT <br><?php echo e($kelas->nama_kelas); ?></h1>
    
    
    <p align="right">
        <a href="/nilai-raport/create" class="button-primary"><button class="add-button">Tambah Data</button></a>
    </p>
    
    <?php if(session ('success')): ?>
        <div class="alert alert-success"><span class="closebtn" id="closeBtn">&times;</span><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session ('error')): ?>
        <div class="alert alert-danger"><span class="closebtn" id="closeBtn">&times;</span><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table-show">
        <thead>
            <tr>
                <th class="border-head" rowspan="2">NO</th>
                <th class="border-head" rowspan="2">NIS</th>
                <th class="border-head" rowspan="2">NAMA SISWA</th>
                <th class="border-head" colspan="6">NILAI</th>
                <th class="border-head" rowspan="2" colspan="3">ACTION</th>
            </tr>
            <tr>
                <th class="border-head">MATEMATIKA</th>
                <th class="border-head">BAHASA INDONESIA</th>
                <th class="border-head">BAHASA INGGRIS</th>
                <th class="border-head">KEJURUAN</th>
                <th class="border-head">M.PILIHAN</th>
                <th class="border-head">RATA - RATA</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border-data" ><?php echo e($loop->iteration); ?></td>
                <td class="border-data" ><?php echo e($data->siswa->nis); ?></td>
                <td class="border-data" ><?php echo e($data->siswa->nama_siswa); ?></td>
                <td class="border-data" ><?php echo e($data->matematika); ?></td>
                <td class="border-data" ><?php echo e($data->indonesia); ?></td>
                <td class="border-data" ><?php echo e($data->inggris); ?></td>
                <td class="border-data" ><?php echo e($data->kejuruan); ?></td>
                <td class="border-data" ><?php echo e($data->pilihan); ?></td>
                <td class="border-data" ><?php echo e($data->rata_rata); ?></td>
                <td class="border-data" style="text-align: center">
                    <div class="action">
                        <a href="/nilai-raport/show/<?php echo e($data->id); ?>"><button class="index-button">VIEW</button></a>
                        <a href="/nilai-raport/edit/<?php echo e($data->id); ?>"><button class="index-button">EDIT</button></a>
                        <a href="/nilai-raport/destroy/<?php echo e($data->id); ?>" onclick="return confirm('Yakin hapus?')" class="button-danger"><button class="index-button">DELETE</button></a>
                    </div> 
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\www\simulasi-1-lsp\resources\views/nilai/index.blade.php ENDPATH**/ ?>